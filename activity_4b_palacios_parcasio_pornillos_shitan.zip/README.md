# Activity 4b
## Members
- PALACIOS, Ned Isaiah
- PARCASIO, James Brian
- PORNILLOS, Joseph Anthony
- SHITAN, Kyla Joy

## Checklist
### Film
- [x] dbselect_film.js
- [x] dbinsert_film.js
- [x] dbupdate_film.js
- [x] dbdelete_film.js

### Customer
- [x] dbselect_customer.js
- [x] dbinsert_customer.js
- [x] dbupdate_customer.js
- [x] dbdelete_customer.js

### Rental
- [x] dbselect_rental.js
- [x] dbinsert_rental.js
- [x] dbupdate_rental.js
- [x] dbdelete_rental.js

### Recording 
- https://drive.google.com/file/d/1y7QIpOpM8BtHL-9vubhyUYYNfjLN1Vxv/view?usp=sharing
- https://drive.google.com/file/d/1PZaidQQtJ6JJK-dz6OZSe6QD8_L4ata_/view?usp=sharing

#### (c) 2021 ScriptKiddies™️